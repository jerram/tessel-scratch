var tessel = require('tessel');
var ws = require("nodejs-websocket")
var PORT = 8000;
var accel = require('accel-mma84').use(tessel.port['A']);
var connection = null;
var server;

// Initialize the accelerometer.
accel.on('ready', function () {
    // Stream accelerometer data
  
	console.log("Accelerometer ready");
	poll();
});

function poll() {
	if(connection != null) {
		console.log("conn not null");
		accel.getAcceleration(function(err, xyz) {
				var x = xyz[0];
				var y = Math.abs(xyz[1]);
				var z = Math.abs(xyz[2]);
				//console.log("X: " + x + "     Y: " + y)
				if(x <= -0.5) {
					console.log("LEFT");
					connection.sendText("LEFT");
				} else if(x >= 0.5) {
					console.log("RIGHT");
					connection.sendText("RIGHT");
				}
				if(y > 0.5) {
					console.log("ROTATE");
					connection.sendText("ROTATE");
				}

				setTimeout(poll, 1000);
		});
	} else {
		console.log("not reading - no connection");
		setTimeout(poll, 1000);
	}
}

accel.on('error', function(err){
  console.log('Accelerometer Error:', err);
});

setupWebsocketServer();

function setupWebsocketServer() {
	// Create the websocket server, provide connection callback
	server = ws.createServer(function (conn) {
		connection = conn;
	  console.log("New websocket connection");	  

	  // // If we get text from the client, and echo it  
	  // conn.on("text", function (str) {
	  //   // print it out 
	  //   console.log("Received "+str)
	  //   // Send it back (but more excited)
	  //   conn.sendText(str.toUpperCase()+"!!!")
	  // });

	  // When the client closes the connection, notify us
	  conn.on("close", function (code, reason) {
	      console.log("Connection closed");
	      connection = null;
	  });
	}).listen(PORT);

	console.log("Listening on port " + PORT);
}
